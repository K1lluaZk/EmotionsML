# Configuraciones globales
FRAME_SKIP = 5  # Analizar solo 1 de cada 5 frames para mejorar FPS
FONT_SCALE = 1.2
TEXT_COLOR = (0, 255, 0)